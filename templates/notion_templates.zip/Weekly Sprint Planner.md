# Weekly Sprint Planner

Use this planner to structure a high-focus week with clear goals and owner accountability.

## Sprint Info
- Sprint week: YYYY-MM-DD
- Sprint goal:

## Top 3 priorities (this week)
1. 
2. 
3. 

## Tasks
- [ ] Task A — Owner — Est (hrs)
- [ ] Task B — Owner — Est (hrs)
- [ ] Task C — Owner — Est (hrs)

## Blockers
- Blocker 1
- Blocker 2

## Meetings
- Mon: Sprint planning (30 min)
- Wed: Mid-week sync (15 min)
- Fri: Demo & retro (30 min)

## Metrics to watch
- Acquisition metric
- Activation metric
- Revenue metric (if applicable)

## Retrospective notes
- What went well
- What didn’t
- Action items for next sprint
