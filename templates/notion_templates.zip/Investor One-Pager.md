# Investor One-Pager

A concise one-page overview for early conversations.

## Company
- Name:
- Tagline (one line):

## Problem
- What problem are you solving?
- Who feels this pain?

## Solution
- What you build
- Why it’s different

## Traction
- Key metrics (users, revenue, MRR, growth)
- Notable logos / pilots

## Business model
- Pricing / revenue model

## Go-to-market
- Main channels and strategy

## Team
- Founder(s) and short background

## Ask
- How much you’re raising
- What you’ll use the money for (30/60/90 day plan)

## Contact
- Email / calendar link
