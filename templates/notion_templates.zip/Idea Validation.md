# Idea Validation

Use this template to test assumptions quickly and gather learning from potential users.

## One-line idea
Describe the idea in one sentence.

## Problem
- Who has this problem?
- How do they solve it today?
- How painful is the problem? (1-10)

## Hypotheses
- Hypothesis 1: (example: early adopters will pay $X for Y)
- Hypothesis 2: (feature A is required)

## Key metrics
- Primary metric (e.g. signups, demo requests)
- Secondary metrics

## Minimum test
- Test type: (landing page / interview / prototype)
- Steps to run the test
  - Create landing page with copy
  - Run 100 targeted outreach messages
  - Measure clicks → signups

## Interview script
- Intro
- Problem questions
- Current solutions
- Willingness to pay
- Close: ask for follow-up

## Learnings
- What we learned
- Next experiments

## Decisions
- Proceed / Pivot / Kill
- Reasoning and next steps
