# Acquisition Checklist

Checklist to run repeatable user acquisition experiments.

## Before you start
- [ ] Define target user persona
- [ ] Define acquisition channel and hypothesis
- [ ] Prepare tracking links (UTM)

## Landing page
- [ ] Clear headline
- [ ] One-line value proposition
- [ ] CTA above the fold
- [ ] Social proof / trust signals

## Outreach
- [ ] Build list (100 prospects)
- [ ] Prepare 3-message outreach sequence
- [ ] Setup follow-up reminders

## Paid channels
- [ ] Create ad copy and creative
- [ ] Setup audience targeting
- [ ] Set daily budget and measurement plan

## Measurement
- [ ] Setup analytics (GA / simple event tracking)
- [ ] Define primary conversion event
- [ ] Monitor CPC / CPA and adjust

## Post-acquisition
- [ ] Onboard new users with email sequence
- [ ] Collect qualitative feedback
- [ ] Add to retention experiments
