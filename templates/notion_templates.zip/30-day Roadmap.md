# 30-day Roadmap

A focused plan to validate and launch a usable MVP within 30 days.

## Goal (30 days)
- One-sentence target (e.g. 50 paid users or 1,000 weekly active users)

## Week 1 — Validate
- Day 1: Finalize value prop and landing copy
- Day 2: Build landing page and analytics (GA or simple UTM)
- Day 3: Create outreach list (100 prospects)
- Day 4: Run first outreach messages
- Day 5: Conduct interviews and collect feedback
- Deliverable: landing + interview notes

## Week 2 — Prototype
- Day 6–7: Build clickable prototype or Notion flow
- Day 8–10: Test prototype with early signups
- Day 11–12: Iterate on core flow
- Day 13–14: Launch first limited beta
- Deliverable: prototype + beta list

## Week 3 — Ship
- Day 15–17: Build MVP (copy, basic features)
- Day 18–19: QA + onboarding flow
- Day 20–21: Launch to beta and start paid checkout (if applicable)
- Deliverable: MVP + checkout

## Week 4 — Scale & Learn
- Day 22–24: Monitor funnels and conversion
- Day 25–27: Run micro-tests for acquisition channels
- Day 28–30: Decide next milestone (grow or iterate)
- Deliverable: Learnings + plan for next 30 days

## Weekly cadence
- Weekly demo & retrospective
- Update roadmap and backlog

## Success criteria
- Define measurable criteria (e.g. 50 signups, 5 paid conversions)
