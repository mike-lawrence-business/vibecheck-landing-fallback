# Quickstart Guide — 10 minutes

Follow these steps to set up the Notion Startup Playbook and start using it.

1. Import templates into Notion
   - Drag each Markdown file into Notion or copy/paste the Markdown into new pages.
2. Create a top-level page "Startup Playbook" and move imported pages under it.
3. Open "Idea Validation" and fill in the one-line idea and priority hypotheses (5 min)
4. Open "30-day Roadmap" and pick the week 1 tasks (3 min)
5. Open "Weekly Sprint Planner" and set this week's top 3 priorities (1 min)
6. Open "Acquisition Checklist" and plan your first outreach batch (1 min)

You're ready — run the experiment, collect feedback, and iterate.

Tips
- Duplicate templates for each new idea or product line.
- Use Notion database templates for tracking tasks and users.
